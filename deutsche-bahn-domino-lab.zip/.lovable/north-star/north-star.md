<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Planejadores ferroviários encontram intervenções que devolvem os trens e passageiros da Alemanha ao horário.

## Métrica

Intervenções em trens simuladas com o saldo de tempo dos passageiros exibido, por semana
