# Diagrama linear estável (sem "pulos" de linhas e trens)

## Por que hoje fica mudando
- A cada passo do relógio, as linhas (corredores) são recalculadas do zero a partir dos trens visíveis.
- A ordem das linhas depende de quantos trens estão nelas **naquele instante**: quando um trem passa para outro trecho, as linhas trocam de posição na tela.
- O bloco "Outros trechos (1–2 trens)" também muda conforme os trens entram e saem.
- Aplicar um filtro ou busca muda o desenho das próprias linhas, não só os trens mostrados.
- Quando um trem inverte o sentido no fim da rota, ele pula de fileira dentro da linha.
- Os ícones dos trens saltam de posição em vez de deslizar.

## O que muda
1. **Linhas fixas na sessão**: o desenho das linhas (estações e trechos) é montado uma vez com todos os trens e só ganha linhas novas quando surgir um trecho novo (desvio, retorno à garagem). Linhas existentes nunca são refeitas.
2. **Ordem fixa**: linhas ordenadas pelo volume total de serviços da sessão, não pelo número de trens no momento. A ordem não muda enquanto os trens andam.
3. **Filtros só escondem trens**: busca, categoria e estado não alteram as linhas; uma linha sem trens visíveis fica recolhida com "0 trens" (ou some só quando o filtro estiver ativo).
4. **"Outros trechos" fixo**: o agrupamento usa o volume da sessão, então uma linha não fica entrando e saindo do bloco.
5. **Fileira fixa por trem**: cada trem recebe sua fileira ao aparecer na linha e a mantém, inclusive ao inverter o sentido (a seta muda, a fileira não). Novos trens entram no fim.
6. **Movimento suave**: o ícone do trem desliza entre posições em vez de pular.

## Verificação
- Teste: após avançar a simulação várias vezes, os ids e a ordem das linhas continuam iguais e cada trem mantém a fileira.
- Teste: aplicar um filtro não altera as linhas.
- Abrir o diagrama no preview em 120× e capturar telas em sequência para confirmar que nada troca de lugar.

## Detalhes técnicos
- `src/lib/line-diagram.ts`: `diagramCorridors` passa a aceitar um layout anterior (`extendCorridors(prev, trains)`) que preserva corredores existentes e só encadeia trechos ainda não atribuídos; guarda `weight` (uso total) para ordenar e agrupar. Atribuição de trens (`assignServices`) separada do layout.
- `src/components/LineDiagram.tsx`: layout em `useRef`, atualizado apenas quando o conjunto de arestas de `props.trains` (não de `filtered`) muda; serviços filtrados atribuídos por cima. Mapa de fileiras por corredor em `useRef` (sticky rows) no lugar da ordenação por sentido/nome em `diagramRows`. Marcadores em `<g transform>` com `transition: transform` CSS.
- Atualizar regra de diagrama em `AGENTS.md` (corredores estáveis por sessão).
- Testes em `src/lib/line-diagram.test.ts`.
