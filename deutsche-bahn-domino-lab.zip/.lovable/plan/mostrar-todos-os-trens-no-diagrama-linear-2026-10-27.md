# Mostrar todos os trens no diagrama linear

## Por que hoje faltam trens
- O diagrama mostra só 8 corredores por página e só o primeiro fica aberto; os outros ficam fechados.
- O filtro inicial é "Em circulação", escondendo parados, aguardando e retornando à garagem.
- Corredores com poucos trens ficam no fim, em páginas que quase ninguém abre.

## O que muda
1. **Sem páginas**: todos os corredores aparecem numa única lista com rolagem.
2. **Todos abertos por padrão**, com botão "Recolher todos / Expandir todos".
3. **Filtro inicial "Todos"**, igual ao mapa.
4. **Contador de conferência** no topo: "Mapa: X trens · Diagrama: X trens" — se algum número divergir, mostra quantos faltam e por quê (sem trajeto, filtro, removido).
5. **Corredores pequenos agrupados**: corredores com 1–2 trens vão para um bloco "Outros trechos" compacto, para a lista não ficar enorme.
6. **Visual compacto**: faixas mais baixas quando há muitos trens, para caber mais na tela.
7. Trens sem trajeto continuam na seção própria, sempre visível no fim.

## Verificação
- Teste: todo trem do mapa aparece exatamente uma vez no diagrama.
- Abrir o preview com dados ao vivo e comparar os dois contadores.

## Detalhes técnicos
- `src/components/LineDiagram.tsx`: remover `PAGE_SIZE`/paginação, estado `expanded` vira conjunto (padrão todos), status padrão `all`, contador comparando `props.trains` com soma de `services` + `unplaced`.
- `src/lib/line-diagram.ts`: helper que separa corredores com <3 serviços em um grupo "Outros trechos".
- Novo teste em `src/lib/line-diagram.test.ts` cobrindo a contagem total.
