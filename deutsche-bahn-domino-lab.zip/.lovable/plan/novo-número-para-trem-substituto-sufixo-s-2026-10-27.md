# Novo número para trem substituto (sufixo "S")

## O que muda
- O trem reserva que sai da garagem passa a ter um número próprio: o número original seguido de **S**. Exemplo: `ICE 521` vira `ICE 521S` (antes era `ICE 521 (subst.)`).
- O mesmo vale para o trem "próximo regular": `ICE 521S` em vez de `ICE 521 (próximo regular)`. No painel, uma etiqueta pequena continua dizendo se ele veio da reserva ou se é o próximo regular.
- O nome novo aparece no mapa, no diagrama linear, nas listas, na comparação por trem e no saldo.

## Detalhes técnicos
- `src/lib/sim.ts` `replacementFor`: `name: \`${t.name}S\``.
- `src/lib/timeline.ts` linha 115: usar o nome `S` em vez de "(próximo regular)"; a origem continua no registro `kind` (reserva/transferência) para a etiqueta.
- Os ids internos (`-sub`) ficam iguais, assim devolver o trem e o retorno à garagem continuam funcionando.
- Atualizar os testes que verificam o nome antigo e adicionar um que confirma `ICE 521` → `ICE 521S`.
